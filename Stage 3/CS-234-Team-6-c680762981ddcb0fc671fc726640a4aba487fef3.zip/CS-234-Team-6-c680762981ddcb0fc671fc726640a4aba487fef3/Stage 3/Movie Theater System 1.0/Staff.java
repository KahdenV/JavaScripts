/**
 * Class representing a staff member, extends the Person class.
 */
public class Staff extends Person {
    public Staff(String name, String email, String password) {
        super(name, email, password);
    }
}